// UK lang variables
tinyMCE.addI18n('en.codehighlighting_dlg',{
codehighlighting_desc : "Code Highlighting",
codehighlighting_title : "Code Highlighting",
codehighlighting_langaugepicker : "Choose the language",
codehighlighting_pagecode : "Paste your code here",
codehighlighting_button_desc: "Insert code",
codehighlighting_nogutter : "No Gutter",
codehighlighting_collapse : "Collapes",
codehighlighting_nocontrols : "No Controls",
codehighlighting_showcolumns : "Show Columns"
});
