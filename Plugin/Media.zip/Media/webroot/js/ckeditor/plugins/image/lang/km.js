﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image', 'km', {
	alertUrl: 'សូមសរសេរងាស័យដ្ឋានរបស់រូបភាព',
	alt: 'អត្ថបទជំនួស',
	border: 'ស៊ុម',
	btnUpload: 'បញ្ជូនទៅកាន់ម៉ាស៊ីនផ្តល់សេវា',
	button2Img: 'Do you want to transform the selected image button on a simple image?', // MISSING
	hSpace: 'គំលាតទទឹង',
	img2Button: 'Do you want to transform the selected image on a image button?', // MISSING
	infoTab: 'ពត៌មានអំពីរូបភាព',
	linkTab: 'ឈ្នាប់',
	lockRatio: 'អត្រាឡុក',
	menu: 'ការកំណត់រូបភាព',
	resetSize: 'កំណត់ទំហំឡើងវិញ',
	title: 'ការកំណត់រូបភាព',
	titleButton: 'ការកំណត់ប៉ូតុនរូបភាព',
	upload: 'ទាញយក',
	urlMissing: 'ខ្វះ URL ប្រភព​រូប​ភាព។',
	vSpace: 'VSpace',
	validateBorder: 'Border must be a whole number.', // MISSING
	validateHSpace: 'HSpace must be a whole number.', // MISSING
	validateVSpace: 'VSpace must be a whole number.' // MISSING
} );
