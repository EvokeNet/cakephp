﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image', 'pl', {
	alertUrl: 'Podaj adres obrazka.',
	alt: 'Tekst zastępczy',
	border: 'Obramowanie',
	btnUpload: 'Wyślij',
	button2Img: 'Czy chcesz przekonwertować zaznaczony przycisk graficzny do zwykłego obrazka?',
	hSpace: 'Odstęp poziomy',
	img2Button: 'Czy chcesz przekonwertować zaznaczony obrazek do przycisku graficznego?',
	infoTab: 'Informacje o obrazku',
	linkTab: 'Hiperłącze',
	lockRatio: 'Zablokuj proporcje',
	menu: 'Właściwości obrazka',
	resetSize: 'Przywróć rozmiar',
	title: 'Właściwości obrazka',
	titleButton: 'Właściwości przycisku graficznego',
	upload: 'Wyślij',
	urlMissing: 'Podaj adres URL obrazka.',
	vSpace: 'Odstęp pionowy',
	validateBorder: 'Wartość obramowania musi być liczbą całkowitą.',
	validateHSpace: 'Wartość odstępu poziomego musi być liczbą całkowitą.',
	validateVSpace: 'Wartość odstępu pionowego musi być liczbą całkowitą.'
} );
